package pkj;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JButton;
import java.awt.GridBagConstraints;
import java.awt.Insets;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JScrollBar;
import javax.swing.JComboBox;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.FormSpecs;

public class practice extends JFrame {
	private JPanel contentPane;
	private JTextField txtname;
	private JTextField txtFName;
	private JTextField txtcnic;
	
	public practice() {
		getContentPane().setLayout(null);
		
		JButton btnForAdminestratorLogin = new JButton("Adminestrator Login");
		btnForAdminestratorLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnForAdminestratorLogin.setBounds(31, 94, 200, 50);
		getContentPane().add(btnForAdminestratorLogin);
		
		JButton btnUserLogin = new JButton("User Login");
		btnUserLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnUserLogin.setBounds(243, 94, 200, 50);
		getContentPane().add(btnUserLogin);
		
		
		
		
		/*setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		setTitle("Online Testing Service");
		GridBagConstraints gbc_btnRegistrationForItc_1 = new GridBagConstraints();
		gbc_btnRegistrationForItc_1.anchor = GridBagConstraints.NORTHWEST;
		gbc_btnRegistrationForItc_1.gridx = 1;
		gbc_btnRegistrationForItc_1.gridy = 1;
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{121, 197, 0};
		gbl_contentPane.rowHeights = new int[]{25, 0, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnRegistrationForGenral = new JButton("Registration for Genral Test");
		btnRegistrationForGenral.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		GridBagConstraints gbc_btnRegistrationForGenral = new GridBagConstraints();
		gbc_btnRegistrationForGenral.insets = new Insets(0, 0, 5, 0);
		gbc_btnRegistrationForGenral.gridx = 1;
		gbc_btnRegistrationForGenral.gridy = 0;
		contentPane.add(btnRegistrationForGenral, gbc_btnRegistrationForGenral);
		
		JButton btnRegistrationForItc = new JButton("Registration for ITC Test");
		btnRegistrationForItc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		GridBagConstraints gbc_btnRegistrationForItc_11 = new GridBagConstraints();
		gbc_btnRegistrationForItc_11.insets = new Insets(0, 0, 5, 0);
		gbc_btnRegistrationForItc_11.anchor = GridBagConstraints.NORTHWEST;
		gbc_btnRegistrationForItc_11.gridx = 1;
		gbc_btnRegistrationForItc_11.gridy = 1;
		getContentPane().add(btnRegistrationForItc, gbc_btnRegistrationForItc_11);*/
	}
	
	/**
	 * Launch the application.
	 */

	/**
	 * Create the frame.
	 */
	/*public void gui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		setTitle("Online Testing Service");
		GridBagConstraints gbc_btnRegistrationForItc_1 = new GridBagConstraints();
		gbc_btnRegistrationForItc_1.anchor = GridBagConstraints.NORTHWEST;
		gbc_btnRegistrationForItc_1.gridx = 1;
		gbc_btnRegistrationForItc_1.gridy = 1;
		GridBagLayout gbl_contentPane = new GridBagLayout();
		gbl_contentPane.columnWidths = new int[]{121, 197, 0};
		gbl_contentPane.rowHeights = new int[]{25, 0, 0};
		gbl_contentPane.columnWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		gbl_contentPane.rowWeights = new double[]{0.0, 0.0, Double.MIN_VALUE};
		contentPane.setLayout(gbl_contentPane);
		
		JButton btnRegistrationForItc = new JButton("Registration for ITC test");
		btnRegistrationForItc.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		GridBagConstraints gbc_btnRegistrationForItc_11 = new GridBagConstraints();
		gbc_btnRegistrationForItc_11.insets = new Insets(0, 0, 5, 0);
		gbc_btnRegistrationForItc_11.anchor = GridBagConstraints.NORTHWEST;
		gbc_btnRegistrationForItc_11.gridx = 1;
		gbc_btnRegistrationForItc_11.gridy = 0;
		getContentPane().add(btnRegistrationForItc, gbc_btnRegistrationForItc_11);
		
		JButton btnRegistrationForGenral = new JButton("Registration for Genral Test");
		btnRegistrationForGenral.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		GridBagConstraints gbc_btnRegistrationForGenral = new GridBagConstraints();
		gbc_btnRegistrationForGenral.gridx = 1;
		gbc_btnRegistrationForGenral.gridy = 1;
		contentPane.add(btnRegistrationForGenral, gbc_btnRegistrationForGenral);
		
		setVisible(true);
	}*/

}
