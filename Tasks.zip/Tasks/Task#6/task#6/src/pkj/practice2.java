package pkj;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.GridBagLayout;
import javax.swing.JLabel;
import java.awt.GridBagConstraints;
import javax.swing.JTextField;
import java.awt.Insets;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class practice2 extends JFrame {

	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtCNIC;
	private JButton btnLogin;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		practice2 frame = new practice2();
		frame.setVisible(true);
	}

	/**
	 * Create the frame.
	 */
	public practice2() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		setTitle("Online Testing Service");
		
		JButton btnPhysicsTest = new JButton("Physics Test");
		btnPhysicsTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnPhysicsTest.setBounds(159, 12, 140, 25);
		getContentPane().add(btnPhysicsTest);
		
		JButton btnGenralTest = new JButton("Genral Test");
		btnGenralTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnGenralTest.setBounds(159, 123, 140, 25);
		getContentPane().add(btnGenralTest);
		
		JButton btnEnglishTest = new JButton("English Test");
		btnEnglishTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		
		JButton btnMathsTest = new JButton("Maths Test");
		btnMathsTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnMathsTest.setBounds(159, 49, 140, 25);
		getContentPane().add(btnMathsTest);
		btnEnglishTest.setBounds(159, 165, 140, 25);
		getContentPane().add(btnEnglishTest);
		
		JButton btnChemistry = new JButton("Chemistry Test");
		btnChemistry.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnChemistry.setBounds(159, 86, 140, 25);
		getContentPane().add(btnChemistry);
		
	}
}
