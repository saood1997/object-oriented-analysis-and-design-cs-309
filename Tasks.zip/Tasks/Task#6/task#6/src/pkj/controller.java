package pkj;

public class controller {
	private model M;
	private View V;
	private boolean flag;
	public controller(View view,model model) {
		M = model;
		V = view;
	}
	
	public void controller() {
		V.firstGUI();
		System.out.println("controller:");
		while(true) {
			System.out.println("");
			if(V.flag==true) {
				flag = M.showUserData(V.getuserName(),V.getuserCNIC());
				if(flag==false) {
					V.registerStudent();
					while(true) {
						System.out.println("while loop2");
						if(V.flag2) {
							M.registerStudent(V.getuserName(),V.getuserFname(),V.getuserCNIC());
						}
						if(M.flag3) {
							System.out.println("flag3 = true");
							int No = V.testNo;
							M.showQuestions(No);
							break;
						}
					}
				}
				else {
					int No = V.testNo;
					M.showQuestions(No);
				}
				V.flag = false;
				break;
			}
			
		}
		
//		while(true) {
//			System.out.println("while loop");
//			if(V.flag==true) {
//				flag = M.showUserData(V.getuserName(),V.getuserCNIC());
//				
//				if(flag==false) {
//					V.registerStudent();
//					while(true) {
//						System.out.println("while loop2");
//						if(V.flag2) {
//							M.registerStudent(V.getuserName(),V.getuserFname(),V.getuserCNIC());
//						}
//						if(M.flag3) {
//							System.out.println("flag3 = true");
//							V.showQuestions();
//							break;
//						}
//					}
//					
//				}
//				else {
//					System.out.println("else condtion");
//					V.showQuestions();
//				}
//				V.flag = false;
//				break;
//			}
//		}
		
	}
}
