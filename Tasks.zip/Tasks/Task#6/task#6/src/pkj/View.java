package pkj;

import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.FormSpecs;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class View extends JFrame {
	public View() {
	}

	private JPanel contentPane;
	private JTextField txtName;
	private JTextField txtCNIC;
	private JButton btnLogin;
	public String Name;
	public String CNIC;
	public String FName;
	private JTextField txtFName;
	
	private JTextField txtname;
	private JTextField txtcnic;
	public int testNo;
	
	public boolean flag = false;
	public boolean flag2 = false;
	public void testNo(int i) {
		testNo = i;
	}
	public void userData() {
		Name = txtName.getText();
		CNIC = txtCNIC.getText();
		flag = true;
		System.out.println("userData ="+Name+CNIC);
	}
	
	public void studentInfo() {
		Name = txtname.getText();
		CNIC = txtcnic.getText();
		FName = txtFName.getText();
		flag2 = true;
	}
	
	public String getuserName() {
		return Name;
	}
	
	public String getuserCNIC() {
		return CNIC;
	}
	
	public String getuserFname() {
		return FName;
	}
	
	public void registerStudent() {
		System.out.println("Student Register");
		
		setTitle("Registration Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblPleaseFirstRegister = new JLabel("First Register Your Self");
		lblPleaseFirstRegister.setBounds(160, -12, 200, 50);
		getContentPane().add(lblPleaseFirstRegister);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(94, 32, 39, 15);
		getContentPane().add(lblName);
		
		txtname = new JTextField();
		txtname.setBounds(172, 30, 124, 19);
		getContentPane().add(txtname);
		txtname.setColumns(10);
		
		JLabel lblFname = new JLabel("FName");
		lblFname.setBounds(90, 56, 47, 15);
		getContentPane().add(lblFname);
		
		txtFName = new JTextField();
		txtFName.setBounds(172, 54, 124, 19);
		getContentPane().add(txtFName);
		txtFName.setColumns(10);
		
		JLabel lblCnic = new JLabel("CNIC");
		lblCnic.setBounds(97, 80, 32, 15);
		getContentPane().add(lblCnic);
		
		txtcnic = new JTextField();
		txtcnic.setBounds(172, 78, 124, 19);
		getContentPane().add(txtcnic);
		txtcnic.setColumns(10);
		
		JButton btnNewButton = new JButton("Save");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				studentInfo();
			}
		});
		btnNewButton.setBounds(172, 136, 124, 31);
		getContentPane().add(btnNewButton);
		
		setVisible(true);
		
	}
	
	public void information() {
		setTitle("User Login");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JLabel lblName = new JLabel("Name");
		lblName.setBounds(65, 37, 39, 15);
		contentPane.add(lblName);
		
		txtName = new JTextField();
		txtName.setBounds(139, 35, 124, 19);
		contentPane.add(txtName);
		txtName.setColumns(10);
		
		JLabel lblCnic = new JLabel("CNIC");
		lblCnic.setBounds(68, 61, 32, 15);
		contentPane.add(lblCnic);
		
		txtCNIC = new JTextField();
		txtCNIC.setBounds(139, 59, 124, 19);
		contentPane.add(txtCNIC);
		txtCNIC.setColumns(10);
		
		btnLogin = new JButton("Login");
		btnLogin.setBounds(256, 83, 72, 25);
		btnLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				userData();
			}
		});
		contentPane.add(btnLogin);
		
		setVisible(true);
	}
	
	public void firstGUI() {
		setTitle("Login Form");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
		setContentPane(contentPane);
		getContentPane().setLayout(null);
		
		JButton btnForAdminestratorLogin = new JButton("Administrator Login");
		btnForAdminestratorLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
			}
		});
		btnForAdminestratorLogin.setBounds(31, 94, 200, 50);
		getContentPane().add(btnForAdminestratorLogin);
		
		JButton btnUserLogin = new JButton("User Login");
		btnUserLogin.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				setGui();
			}
		});
		btnUserLogin.setBounds(243, 94, 200, 50);
		getContentPane().add(btnUserLogin);
		
		setVisible(true);
	}
	
	public void setGui() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 300);
		JPanel contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		setTitle("Online Testing Service");
		
		JButton btnPhysicsTest = new JButton("Physics Test");
		btnPhysicsTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				information();
				testNo(1);
			}
		});
		btnPhysicsTest.setBounds(159, 12, 140, 25);
		getContentPane().add(btnPhysicsTest);
		
		JButton btnMathsTest = new JButton("Maths Test");
		btnMathsTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				information();
				testNo(2);
			}
		});
		btnMathsTest.setBounds(159, 49, 140, 25);
		getContentPane().add(btnMathsTest);
		
		JButton btnChemistry = new JButton("Chemistry Test");
		btnChemistry.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				information();
				testNo(3);
			}
		});
		btnChemistry.setBounds(159, 86, 140, 25);
		getContentPane().add(btnChemistry);
		
		JButton btnGenralTest = new JButton("Genral Test");
		btnGenralTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				information();
				testNo(4);
			}
		});
		btnGenralTest.setBounds(159, 123, 140, 25);
		getContentPane().add(btnGenralTest);
		
		JButton btnEnglishTest = new JButton("English Test");
		btnEnglishTest.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				information();
				testNo(5);
			}
		});
		btnEnglishTest.setBounds(159, 165, 140, 25);
		getContentPane().add(btnEnglishTest);
		
		setVisible(true);
	}

}
	