package pkj;

public class Main {
	
	public static void main(String[] args) {
		View view = new View();
		model model = new model();
		//practice p = new practice();
		controller con = new controller(view,model);
		
		con.controller();
		//p.gui();
	}
	
}
