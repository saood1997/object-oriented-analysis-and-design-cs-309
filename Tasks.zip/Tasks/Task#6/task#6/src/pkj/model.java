package pkj;

import javax.swing.JOptionPane;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import com.jgoodies.forms.layout.FormLayout;
import com.jgoodies.forms.layout.ColumnSpec;
import com.jgoodies.forms.layout.RowSpec;
import com.jgoodies.forms.layout.FormSpecs;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.GridBagLayout;
import java.awt.GridBagConstraints;
import java.awt.Insets;

public class model {
	public Connection cn;
	private java.sql.Statement s;
	private String query;
	public boolean flag1 = false;
	public boolean flag3 = false;
	public void connectionDatabase() {
		try {
			cn = DriverManager.getConnection("jdbc:mysql://localhost/Test","root","");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			JOptionPane.showMessageDialog(null, "Could Not Connect: \nReason: "+e.getMessage());
		}
	}
	
	public void registerStudent(String Name,String FName,String CNIC) {
		connectionDatabase();
		String query = "Insert into student values('"+Name+"','"+FName+"','"+CNIC+"')";
		try {
			s = cn.createStatement();
			s.execute(query);
			System.out.println("Student Register");
		} catch (SQLException e){
			e.printStackTrace();
		}
		flag3 = true;
	}
	
	@SuppressWarnings("resource")
	public void showQuestions(int testNo) {
		JOptionPane.showMessageDialog(null, "Hi how are you.Enjoy Question.Good luck");
		connectionDatabase();
		ResultSet res;
		ResultSet rs;
		String query = "Select *from questions";
		String query1 = "select *from options";
		try {
			s = cn.createStatement();
			res = s.executeQuery(query);
			
			while(res.next()) {
				int id = res.getInt("q_id");
				String question = res.getString("question");
				System.out.println(question);
				rs = s.executeQuery(query1);
				while(rs.next()) {
					String a = res.getString("a");
					String b = res.getString("b");
					String c = res.getString("c");
					String d = res.getString("d");
					System.out.println(a);
					System.out.println(b);
					System.out.println(c);
					System.out.println(d);
				}
			}
		} catch (SQLException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//System.out.println("Hi how are you.Enjoy Question.Good luck");
	}
	
	public boolean showUserData(String Name,String CNIC) {
		connectionDatabase();
		ResultSet res;
		String query = "Select *from student";
		try {
			s = cn.createStatement();
			res = s.executeQuery(query);
			
			while(res.next()) {
				String Name1 = res.getString("Name");
				String Fname = res.getString("FName");
		        String CNIC1 = res.getString("CNIC");
		        if(CNIC.contentEquals(res.getString("CNIC"))){
		        	System.out.println("CNIC Found :"+CNIC);
		        	flag1 = true;
		        }
			}
		} catch (SQLException e){
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return flag1;
	}
}
